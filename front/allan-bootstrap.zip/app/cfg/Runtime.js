Ext.define('Homeostat.cfg.Runtime',{
    singleton : true,
    config : {
        token : null,
        myLastCustomer : 0   // initialize to 0
    },
    constructor : function(config){
        this.initConfig(config);
    }
});
