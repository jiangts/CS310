var debug;
Ext.define('Homeostat.Application', {
    name: 'Homeostat',

    extend: 'Ext.app.Application',

    requires: 'Homeostat.cfg.Runtime',

    views: [
        // TODO: add views here
    ],

    controllers: [
        'Nav',
        'UserMenu'
    ],

    stores: [
        'NavTree'
    ]
});
