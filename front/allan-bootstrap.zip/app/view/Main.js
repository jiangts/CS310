Ext.define('Homeostat.view.Main', {
    extend: 'Ext.container.Container',
    requires:[
        'Ext.tab.Panel',
        'Ext.layout.container.Border',
        'Homeostat.view.Header',
        'Homeostat.view.Navigation'
    ],
    
    xtype: 'app-main',

    layout: {
        type: 'border'
    },

    items: [{
        region: 'north',
        xtype: 'app-header',
        height: 60
    },{
        region: 'west',
        xtype: 'app-nav',
        width: 150
    },{
        region: 'center',
        xtype: 'tabpanel',
        items:[{
            title: 'Center Tab 1'
        },{
            title: 'Test TreePanel',
            xtype: 'treepanel',
            store: Ext.create('Homeostat.store.NavTree')//Ext.data.StoreManager.lookup('nav-tree-store') 
        }]
    }]
});
