Ext.define('Homeostat.view.Navigation', {
    extend: 'Ext.tree.Panel',
    requires:[
        'Ext.tree.Panel',
        'Homeostat.store.NavTree'
    ],
    
    xtype: 'app-nav',
    cls: 'no-icon',

    title: 'Navigation Menu',

    rootVisible: false,
    useArrows: true,
    store: Ext.create('Homeostat.store.NavTree')

});
