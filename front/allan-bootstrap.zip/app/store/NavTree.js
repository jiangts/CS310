Ext.define('Homeostat.store.NavTree', {
    storeId: 'nav-tree-store',
    root: {
        expanded: true,
        children: [
            { text: "detention", leaf: true },
            { text: "homework", expanded: true, children: [
                { text: "book report", leaf: true },
                { text: "algebra", leaf: true}
            ] },
            { text: "User Settings", leaf: true }
        ]
    }
});
