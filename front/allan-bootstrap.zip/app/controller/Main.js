Ext.define('Homeostat.controller.Main', {
    extend: 'Ext.app.Controller'
    
    /*
    ,

    refs: [{
        ref: 'navtree',
        selector: 'app-nav'
    }],

    init: function() {
        this.control({
            'app-nav': {
                itemclick: this.addTab
            }
        });
    },

    addTab: function(ths, rec, item) {
    }
    */
});
