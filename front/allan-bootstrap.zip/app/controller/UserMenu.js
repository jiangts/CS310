Ext.define('Homeostat.controller.UserMenu', {
    extend: 'Ext.app.Controller',

    /*
    refs: [{
        ref: 'navtree',
        selector: 'app-nav'
    }],
    */

    init: function() {
        this.control({
            'app-header > button > menu > menuitem': {
                click: this.addTab
            }
        });
    },

    addTab: function(item) {
        if(item.text == "User Settings"){
            this.getController('Nav').addTab(item);
        }
    }
});
