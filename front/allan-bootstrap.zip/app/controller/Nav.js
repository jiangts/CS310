Ext.define('Homeostat.controller.Nav', {
    extend: 'Ext.app.Controller',

    refs: [{
        ref: 'navtree',
        selector: 'app-nav'
    },{
        ref: 'maintabs',
        selector: 'app-main > tabpanel'
    }],

    init: function() {
        this.control({
            'app-nav': {
                itemclick: this.addTab
            },
            'app-main > tabpanel': {
                tabchange: this.treeTabSync
            }
        });
    },

    addTab: function(ths, rec, item) {
        if(!rec || rec.data.leaf == true){
            //if we are calling the function without clicking on a treenode
            //ex, it is through clicking on a menu
            if(!rec){
                var title = ths.text;
            } else {
                //tree node title
                var title = rec.data.text;
            }
            //get tabpanel
            var tabs = this.getMaintabs();

            //get names of all open tabs
            var tabnames = [];
            for(idx in tabs.items.items){
                tabnames.push(tabs.items.items[idx].title);
            }

            var index = tabnames.indexOf(title);
            //open new tab if not already open
            if(index == -1) {
                var tab = tabs.add({
                    title: title,
                    html: 'Tab #' + (tabs.items.length + 1),
                    closable: true
                });
                tabs.setActiveTab(tab);
            } else {
                tabs.setActiveTab(index);
            }
        }
    },

    treeTabSync: function(tabPanel, newCard, oldCard) {
        var title = newCard.title;
        var openTreeLeaves = [];
        var navtree = this.getNavtree().getSelectionModel();
        for(idx in navtree.store.data.items){
            openTreeLeaves.push(navtree.store.data.items[idx].data.text);
        }

        var exist = openTreeLeaves.indexOf(title);
        if(exist != -1){
            navtree.select(exist);
        } else {
            navtree.deselectAll();
        }
    }

});
